package exercicio_noite;

import exercicio1.Exercicio1;
import exercicio2.Exercicio2;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//new Exercicio1();
		new Exercicio2();

	}

}
