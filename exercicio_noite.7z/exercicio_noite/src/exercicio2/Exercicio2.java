/*
 * Fa�a um programa simples do tipo MasterMind
 * 1 - Criar arraylist de String's
 * 2 - Pe�a ao utilizador os numeros
 * 3 - Criar uma funcao que verifique quantos numeros o utilizador acertou e se ganhou ou nao, retornando true ou false
 * 4 - Guarde todas as tentativas do utilizador
 * 5 - Quando o utilizador ganhar mostre todas as tentativas
 */

package exercicio2;

import java.util.ArrayList;
import java.util.Scanner;

public class Exercicio2 {

	Scanner read = new Scanner(System.in);
	ArrayList<String> lista = new ArrayList<String>();
	char[] num = new char[]{'1','9','4','2','7'};
	String tentativa;
	
	public Exercicio2() {
		int opc;
		boolean sair;
		
		do
		{
			System.out.println("Insira os numeros: ");
			tentativa = read.nextLine();
			
			lista.add(tentativa);
			
			sair=verif(tentativa);
			
			for(int i=0;i<lista.size();i++) System.out.println("Tentativa " + (i+1) + ": " + lista.get(i));
			
		}while(sair!=true);
	}
	
	public boolean verif(String tent){
		char[] numeros = new char[tent.length()];
		int cont=0;
		tent.getChars(0, tent.length(), numeros, 0);
		
		for(int i=0;i<tent.length();i++)
		{
			for(int j=0;j<tent.length();j++)
			{
				if(numeros[i]==num[j]) cont++;
			}
		}
		
		System.out.println("Acertou " + cont + "numeros!");
		
		tentativa=new String(numeros);
		
		if(cont==5)
		{
			System.out.println("Parab�ns Ganhou!");
			return true;
		}
		else return false;
	}

}
