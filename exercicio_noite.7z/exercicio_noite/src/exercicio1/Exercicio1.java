/*
 * O programa deve:
 * 1 - Inserir elementos numa arraylist de String's
 * 2 - Listar esses elementos
 * 3 - Encript�-los com o seguinte algoritmo:
 * 		- Reverter a frase ("Galo"="olaG")
 * 		- Trocar as letras com a letra que vem imediatamente a seguir a ela ("Galo"="aGol")
 * 		- Acrescentar o valor 125 em ascii em cada caracter
 * O resultado deve ser o seguinte: "Carpinteiro"="�����������"
 */
package exercicio1;

import java.util.Scanner;
import java.util.ArrayList;

public class Exercicio1 {

	Scanner read = new Scanner(System.in);
	
	ArrayList<String> lista = new ArrayList<String>();
	
	public Exercicio1() {
		String frase;
		int opc;
		boolean encriptado=false;
		
		
		do
		{
			System.out.println("1 - Inserir\n2 - Listar\n3 - Encriptar\n4 - Desincriptar\n0 - Sair\nInsira a opcao: ");
			opc = read.nextInt();
			
			switch(opc)
			{
			case 1:
				if(encriptado==false)
				{
					read.nextLine();
					System.out.println("Insira a frase: ");
					frase=read.nextLine();
					lista.add(frase);
				}
				else System.out.println("� necess�rio desincriptar primeiro as frases!");
				
				break;
				
			case 2:
				for(int i=0;i<lista.size();i++) System.out.println("Frase " + (i+1) + ": " + lista.get(i));
				break;
				
			case 3:
				for(int i=0;i<lista.size();i++)
				{
					lista.set(i, encriptar(lista.get(i)));
				}
				encriptado=true;
				break;
				
			case 4:
				for(int i=0;i<lista.size();i++)
				{
					lista.set(i, desincriptar(lista.get(i)));
				}
				encriptado=false;
				break;
			}
			
		}while(opc!=0);
		
		
	}
	
	public String encriptar(String frase){
		char temp;
		char[] array = new char[frase.length()];
		
		frase.getChars(0, frase.length(), array, 0);
		
		for(int i=0;i<frase.length()/2;i++)
		{
			temp=array[i];
			array[i]=array[frase.length()-1-i];
			array[frase.length()-1-i]=temp;
		}
		
		for(int i=0;i<frase.length();i++){
			if(i%2==0 && i+1<frase.length())
			{
				temp=array[i];
				array[i]=array[i+1];
				array[i+1]=temp;
			}
			array[i]=(char) (array[i]+125);
		}
		
		frase = new String(array);
				
		return frase;
		
	}
	
	public String desincriptar(String frase){
		char temp;
		char[] array = new char[frase.length()];
		
		frase.getChars(0, frase.length(), array, 0);
		
		for(int i=0;i<frase.length();i++){
			array[i]=(char) (array[i]-125);
		}
		
		for(int i=0;i<frase.length();i++){
			if(i%2==0 && i+1<frase.length())
			{
				temp=array[i];
				array[i]=array[i+1];
				array[i+1]=temp;
			}
			
		}
		
		for(int i=0;i<frase.length()/2;i++)
		{
			temp=array[i];
			array[i]=array[frase.length()-1-i];
			array[frase.length()-1-i]=temp;
		}
		
		
		
		frase = new String(array);
				
		return frase;
	}

}
